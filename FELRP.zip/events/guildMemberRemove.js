module.exports = member => {
  let guild = member.guild;
  member.send('niye gittin?');

};
